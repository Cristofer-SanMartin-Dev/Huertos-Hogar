// src/tests/setup.js
import '@testing-library/jest-dom';